import "./App.css";
import Menu from "./Menu";
import Welcome from "./Welcome";
import { useEffect, useState } from "react";

function App() {
  const [isHidden, setIsHidden] = useState(false);
  const [basket, setBasket] = useState(false);
  const buttonClick = (event) => {
    event.preventDefault();

    setIsHidden((prevState) => !prevState);
  };
  const basketClick = (event) => {
    event.preventDefault();
    setBasket((prevState) => !prevState);
  };

  useEffect(() => {
    if (isHidden) {
      console.log(isHidden);
    }
  }, [isHidden]);

  return (
    <div className="App">
      {!isHidden && <Welcome buttonClick={buttonClick} />}
      {isHidden && (
        <Menu
          isHidden={isHidden}
          buttonClick={buttonClick}
          basketClick={basketClick}
          basket={basket}
          setBasket={setBasket}
        />
      )}
    </div>
  );
}

export default App;
