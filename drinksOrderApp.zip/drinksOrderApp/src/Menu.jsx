import React, { useState, useEffect } from "react";
import Card from "./UI/Card";
import Button from "./UI/Button";
import MenuItem from "./MenuItem";
import priceData from "./PriceData/price";
import { FaRegSnowflake } from "react-icons/fa";
import { FaBasketShopping } from "react-icons/fa6";
import { FaFireAlt } from "react-icons/fa";
import { FaBackspace } from "react-icons/fa";
import Basket from "./Basket";

function Menu(props) {
  const [counts, setCounts] = useState({}); // Tüm içeceklerin sayımını tut

  const [allDrinksData, setAllDrinksData] = useState(null); // Tüm veriyi burada tutacağız
  const [selectedType, setSelectedType] = useState("hot");
  const [drinkData, setDrinkData] = useState([]); // Sıcak/soğuk içecek verisini burada tutacağız

  const fetchAllDrinks = async () => {
    try {
      const response = await fetch("https://api.sampleapis.com/coffee/hot");
      const data = await response.json();
      setAllDrinksData(data); // Tüm veriyi saklıyoruz
    } catch (error) {
      console.error("Error fetching coffee data:", error);
    }
  };

  useEffect(() => {
    // Komponent yüklendiğinde verileri getiriyoruz
    fetchAllDrinks();
  }, []);

  const icedClick = () => {
    console.log("iced çalıştı");
    setSelectedType("iced");
    if (allDrinksData) {
      const icedDrinksData = allDrinksData.slice(12, 20); // 12. elemandan 20. elemana kadar alıyoruz
      setDrinkData(icedDrinksData); // Soğuk kahve verisini set ediyoruz
    }
  };

  const hotClick = () => {
    console.log("hot çalıştı");
    setSelectedType("hot");
    if (allDrinksData) {
      const hotDrinksData = allDrinksData.slice(0, 12); // İlk 12 elemanı alıyoruz
      setDrinkData(hotDrinksData); // Sıcak kahve verisini set ediyoruz
    }
  };

  const setCount = (itemTitle, delta) => {
    setCounts((prevCounts) => {
      const newCount = (prevCounts[itemTitle] || 0) + delta;
      return { ...prevCounts, [itemTitle]: Math.max(newCount, 0) }; // Sayım sıfırdan düşük olamaz
    });
  };

  return (
    <div>
      <Card>
        {props.basket ? (
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <Button className="basketButton" onClick={props.basketClick}>
              <FaBasketShopping style={{ fontSize: "18px" }} />
            </Button>
          </div>
        ) : (
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <Button className="backButton" onClick={props.buttonClick}>
              <FaBackspace />
            </Button>
            <Button className="basketButton" onClick={props.basketClick}>
              <FaBasketShopping style={{ fontSize: "18px" }} />
            </Button>
          </div>
        )}

        {props.basket ? (
          <Basket counts={counts} />
        ) : (
          <>
            <div style={{ textAlign: "center" }}>
              <h3>İçeceğinizi Nasıl Tercih Edersiniz</h3>
              <div style={{ display: "flex", justifyContent: "space-evenly" }}>
                <Button
                  onClick={icedClick}
                  className="filterButton iceFilterButton"
                >
                  <FaRegSnowflake /> Soğuk
                </Button>
                <Button
                  onClick={hotClick}
                  className="filterButton hotFilterButton"
                >
                  <FaFireAlt /> Sıcak
                </Button>
              </div>
            </div>
            <MenuItem
              data={drinkData}
              priceData={priceData}
              counts={counts}
              setCount={setCount}
            />
          </>
        )}
      </Card>
    </div>
  );
}

export default Menu;
