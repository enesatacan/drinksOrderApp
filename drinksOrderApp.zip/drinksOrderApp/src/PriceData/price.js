const priceData = {
  drinks: [
    {
      name: "Black Coffee",
      price: 50,
    },
    {
      name: "Latte",
      price: 50,
    },
    {
      name: "Caramel Latte",
      price: 55,
    },
    {
      name: "Cappuccino",
      price: 55,
    },
    {
      name: "Americano",
      price: 45,
    },
    {
      name: "Espresso",
      price: 30,
    },
    {
      name: "Macchiato",
      price: 60,
    },
    {
      name: "Mocha",
      price: 60,
    },
    {
      name: "Hot Chocolate",
      price: 65,
    },
    {
      name: "Chai Latte",
      price: 55,
    },
    {
      name: "Matcha Latte",
      price: 50,
    },
    {
      name: "Seasonal Brew",
      price: 60,
    },
    {
      name: "Iced Coffee",
      price: 50,
    },
    {
      name: "Iced Espresso",
      price: 40,
    },
    {
      name: "Cold Brew",
      price: 50,
    },
    {
      name: "Frappuccino",
      price: 55,
    },
    {
      name: "Nitro",
      price: 45,
    },
    {
      name: "Mazagran",
      price: 55,
    },
    {
      name: "Svart Te",
      price: 70,
    },
    {
      name: "Islatte",
      price: 65,
    },
    {
      name: "Islatte Mocha",
      price: 60,
    },
    {
      name: "Frapino Caramel",
      price: 75,
    },
    {
      name: "Frapino Mocka",
      price: 70,
    },
    {
      name: "Apelsinjuice",
      price: 55,
    },
    {
      name: "Frozen Lemonade",
      price: 55,
    },
    {
      name: "Lemonad",
      price: 50,
    },
  ],
};

export default priceData;
