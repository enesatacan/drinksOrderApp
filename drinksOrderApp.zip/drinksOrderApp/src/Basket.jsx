import React from "react";
import Button from "./UI/Button";
import priceData from "./PriceData/price"; // priceData'nın bulunduğu dosyanın yolunu buraya ekle

function Basket({ counts }) {
  // Toplam ürün adedini hesapla
  const totalItemCount = counts
    ? Object.values(counts).reduce((acc, count) => acc + count, 0)
    : 0;

  // Toplam fiyatı hesapla
  const totalPrice = Object.entries(counts).reduce(
    (acc, [drinkName, count]) => {
      const drink = priceData.drinks.find((drink) => drink.name === drinkName); // İçeceği bul
      const price = drink ? drink.price : 0; // Fiyatı al (bulamazsa 0)
      return acc + price * count; // Toplam fiyatı güncelle
    },
    0
  );

  return (
    <div>
      <h2>Sepetiniz</h2>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>Toplam Ürün Adedi: {totalItemCount}</span>
        <span>Toplam Tutar: {totalPrice} ₺</span>
      </div>
      <Button className="orderButton" onClick={() => window.location.reload()}>
        Siparişi Tamamla
      </Button>
    </div>
  );
}

export default Basket;
