import "./UI/styles/Menu.css";

function MenuItem({ data, priceData, counts, setCount }) {
  return (
    <>
      <div className="menu">
        {data.length > 0 &&
          data.map((item, index) => {
            // Drink fiyatını al
            const drink = priceData.drinks.find(
              (drink) => drink.name === item.title
            );
            const totalPrice = drink
              ? drink.price * (counts[item.title] || 0)
              : 0; // Fiyatı burada hesapla

            return (
              <div key={index} className="menuItem">
                <img className="menu-image" src={item.image} alt={item.title} />
                <h3 className="menu-name">{item.title}</h3>
                <div className="menu-price">
                  <span>{drink ? drink.price : "Fiyat yok"}₺</span>
                </div>
                <div className="menu-count">
                  <button onClick={() => setCount(item.title, -1)}> - </button>
                  <span> {counts[item.title] || 0} </span>
                  <button onClick={() => setCount(item.title, 1)}> + </button>
                </div>
                <div className="menu-totalPrice">{totalPrice}₺</div>{" "}
                {/* Toplam fiyatı burada göster */}
              </div>
            );
          })}
      </div>
    </>
  );
}

export default MenuItem;
