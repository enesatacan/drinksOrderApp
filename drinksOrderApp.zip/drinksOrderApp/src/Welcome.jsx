import Card from "./UI/Card";
import Button from "./UI/Button";

function Welcome(props) {
  return (
    <div>
      <Card className="welcome">
        <h1>Hoş Geldiniz</h1>
        <span className="paragraph">Haydi Hemen Siparişini Oluşturalım.</span>
        <Button onClick={props.buttonClick}>Menüyü İncele</Button>
      </Card>
    </div>
  );
}

export default Welcome;
